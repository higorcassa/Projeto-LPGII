<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Necessity extends Model
{
    public $fillable = ['descricao'];
}
