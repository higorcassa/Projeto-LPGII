<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exemptiom extends Model
{
    public $fillable = ['motivo'];

}
