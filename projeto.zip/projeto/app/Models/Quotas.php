<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quota extends Model
{
    public $fillable = ['descricao'];
}
